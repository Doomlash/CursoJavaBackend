package net.dmoreno.webLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebLoginApplication.class, args);
	}

}
